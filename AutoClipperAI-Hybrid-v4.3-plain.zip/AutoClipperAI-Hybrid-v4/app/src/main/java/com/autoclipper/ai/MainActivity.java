package com.autoclipper.ai;

import android.app.Activity;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import org.json.*;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private static final String PREFS="autoclipper_v43_plain";
    private static final String GEMINI_BASE="https://generativelanguage.googleapis.com/v1beta";
    private final ExecutorService pool=Executors.newCachedThreadPool();
    private SharedPreferences prefs;
    private LinearLayout root,keyList,resultButtons;
    private EditText backend,youtube,keyInput,durInput,countInput;
    private TextView status,result,quotaInfo;
    private ProgressBar progress;
    private String lastJobId="";

    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private TextView tv(String s,float size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.rgb(235,230,240));t.setPadding(dp(4),dp(5),dp(4),dp(5));return t;}
    private Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;}

    @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences(PREFS,MODE_PRIVATE);buildUi();}

    private void buildUi(){
        ScrollView sv=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(18),dp(18),dp(28));root.setBackgroundColor(Color.rgb(18,15,23));sv.addView(root);setContentView(sv);
        TextView title=tv("AutoClipper AI v4.3 Hybrid",29);title.setTypeface(null,1);title.setTextColor(Color.WHITE);root.addView(title);
        root.addView(tv("APK menangani Gemini • Backend menangani YouTube/Whisper/FFmpeg",15));

        root.addView(tv("Backend URL",18));
        backend=new EditText(this);backend.setSingleLine(true);backend.setHint("http://192.168.1.5:8000");backend.setText(prefs.getString("backend","http://10.0.2.2:8000"));root.addView(backend);
        Button health=btn("🔌 Tes koneksi backend");root.addView(health);health.setOnClickListener(v->testBackend());

        root.addView(tv("Gemini API Keys",18));
        root.addView(tv("Key disimpan lokal di HP tanpa enkripsi. APK memanggil Gemini langsung; key tidak dikirim ke backend. Status kuota hanya berdasarkan respons API, bukan angka sisa kuota.",12));
        keyList=new LinearLayout(this);keyList.setOrientation(LinearLayout.VERTICAL);root.addView(keyList);
        keyInput=new EditText(this);keyInput.setSingleLine(true);keyInput.setHint("AIza...");root.addView(keyInput);
        LinearLayout row=new LinearLayout(this);Button add=btn("+ Tambah Key");Button check=btn("Cek Key & Kuota");row.addView(add,new LinearLayout.LayoutParams(0,dp(52),1));row.addView(check,new LinearLayout.LayoutParams(0,dp(52),1));root.addView(row);
        add.setOnClickListener(v->addKey());
        check.setOnClickListener(v->checkKeys());
        refreshKeys();
        quotaInfo=tv("",13);root.addView(quotaInfo);

        root.addView(tv("YouTube URL",18));youtube=new EditText(this);youtube.setSingleLine(true);youtube.setHint("https://www.youtube.com/watch?v=...");root.addView(youtube);
        root.addView(tv("Durasi clip (detik)",18));durInput=new EditText(this);durInput.setSingleLine(true);durInput.setInputType(2);durInput.setText("45");root.addView(durInput);
        root.addView(tv("Jumlah clip",18));countInput=new EditText(this);countInput.setSingleLine(true);countInput.setInputType(2);countInput.setText("5");root.addView(countInput);
        Button analyze=btn("✨ TRANSKRIPSI + ANALISIS GEMINI");root.addView(analyze);
        progress=new ProgressBar(this);progress.setVisibility(View.GONE);root.addView(progress);
        status=tv("Siap.",15);root.addView(status);root.addView(tv("Hasil AI",22));result=tv("",16);root.addView(result);resultButtons=new LinearLayout(this);resultButtons.setOrientation(LinearLayout.VERTICAL);root.addView(resultButtons);
        analyze.setOnClickListener(v->{String u=youtube.getText().toString().trim();if(u.isEmpty()){toast("Masukkan URL YouTube");return;}int d=parseInt(durInput.getText().toString(),45);int c=parseInt(countInput.getText().toString(),5);if(d<15||d>600){toast("Durasi clip: 15–600 detik");return;}if(c<1||c>30){toast("Jumlah clip: 1–30");return;}analyze(u,d,c);});
    }

    private int parseInt(String s,int def){try{return Integer.parseInt(s.trim());}catch(Exception e){return def;}}
    private String base(){String b=backend.getText().toString().trim();while(b.endsWith("/"))b=b.substring(0,b.length()-1);return b;}

    private JSONArray loadKeys(){
        try{
            String plain=prefs.getString("keys_plain","");
            if(plain==null||plain.trim().isEmpty()) return new JSONArray();
            return new JSONArray(plain);
        }catch(Exception e){
            return new JSONArray();
        }
    }

    private boolean saveKeys(JSONArray a){
        try{
            return prefs.edit().putString("keys_plain",a.toString()).commit();
        }catch(Exception e){
            return false;
        }
    }

    private void refreshKeys(){
        keyList.removeAllViews();JSONArray a=loadKeys();
        if(a.length()==0){TextView empty=tv("Belum ada API key tersimpan.",13);keyList.addView(empty);}
        for(int i=0;i<a.length();i++){try{final int idx=i;JSONObject o=a.getJSONObject(i);LinearLayout r=new LinearLayout(this);String st=o.optString("status","NOT_CHECKED");String model=o.optString("model","");String label=mask(o.optString("key"))+"  ["+st+"]"+(model.isEmpty()?"":"\n"+model);TextView t=tv(label,13);Button del=btn("Hapus");r.addView(t,new LinearLayout.LayoutParams(0,dp(58),1));r.addView(del,new LinearLayout.LayoutParams(dp(82),dp(58)));del.setOnClickListener(v->{JSONArray x=loadKeys();x.remove(idx);if(!saveKeys(x)){toast("Gagal menghapus key");return;}refreshKeys();});keyList.addView(r);}catch(Exception ignored){}}
    }
    private String mask(String k){if(k.length()<=10)return k;return k.substring(0,6)+"••••••"+k.substring(k.length()-4);}

    private boolean addCurrentInputIfNeeded(){
        String k=keyInput.getText().toString().trim();
        if(k.isEmpty()) return false;
        JSONArray a=loadKeys();
        for(int i=0;i<a.length();i++){
            JSONObject existing=a.optJSONObject(i);
            if(existing!=null && k.equals(existing.optString("key"))){
                return true;
            }
        }
        try{
            JSONObject o=new JSONObject();
            o.put("key",k);
            o.put("status","NOT_CHECKED");
            o.put("model","");
            o.put("checked",0);
            a.put(o);
            if(!saveKeys(a)){
                a.remove(a.length()-1);
                runOnUiThread(()->toast("Gagal menyimpan API key. Penyimpanan terenkripsi HP bermasalah."));
                return false;
            }
            keyInput.setText("");
            refreshKeys();
            return true;
        }catch(Exception e){
            runOnUiThread(()->toast("Gagal menyimpan key: "+e.getMessage()));
            return false;
        }
    }

    private void addKey(){
        if(keyInput.getText().toString().trim().isEmpty()){
            toast("API key kosong");
            return;
        }
        if(addCurrentInputIfNeeded()) toast("Key ditambahkan");
    }

    private void checkKeys(){
        // v4.1: bila user mengetik key tetapi lupa menekan "+ Tambah Key",
        // tombol ini otomatis memasukkan key tersebut sebelum pengecekan.
        if(!keyInput.getText().toString().trim().isEmpty()) addCurrentInputIfNeeded();
        JSONArray current=loadKeys();
        if(current.length()==0){
            toast("Masukkan Gemini API Key terlebih dahulu");
            return;
        }
        progress.setVisibility(View.VISIBLE);
        status.setText("Memeriksa akses Gemini...");
        pool.submit(()->{
            JSONArray a=loadKeys();
            int valid=0,limited=0,invalid=0,errors=0;
            for(int i=0;i<a.length();i++){
                try{
                    JSONObject o=a.getJSONObject(i);
                    String key=o.optString("key").trim();
                    GeminiCheck gc=geminiCheck(key);
                    o.put("status",gc.status);
                    o.put("model",gc.model);
                    o.put("checked",System.currentTimeMillis());
                    if("VALID".equals(gc.status)) valid++;
                    else if("RATE_LIMITED".equals(gc.status)||"QUOTA_EXCEEDED".equals(gc.status)) limited++;
                    else if("INVALID".equals(gc.status)) invalid++;
                    else errors++;
                    final int n=i+1,total=a.length();
                    runOnUiThread(()->status.setText("Cek Gemini: "+n+"/"+total));
                }catch(Exception ignored){errors++;}
            }
            saveKeys(a);
            int v=valid,l=limited,iv=invalid,er=errors;
            runOnUiThread(()->{
                progress.setVisibility(View.GONE);
                refreshKeys();
                quotaInfo.setText("Hasil: "+v+" VALID, "+l+" rate/quota limited, "+iv+" INVALID, "+er+" ERROR. Angka sisa quota tidak tersedia dari endpoint ini.");
                status.setText("Pengecekan selesai.");
                toast("Pengecekan selesai");
            });
        });
    }

    private static class GeminiCheck{String status,model;GeminiCheck(String s,String m){status=s;model=m;}}
    private GeminiCheck geminiCheck(String key){
        try{
            HttpResult models=httpGet(GEMINI_BASE+"/models",key,30000);
            if(models.code==401||models.code==403)return new GeminiCheck("INVALID","");
            if(models.code==429)return new GeminiCheck("RATE_LIMITED","");
            if(models.code>=400)return new GeminiCheck("ERROR_"+models.code,"");
            String model=chooseModel(models.body);if(model.isEmpty())return new GeminiCheck("NO_MODEL","");
            JSONObject body=new JSONObject();JSONArray contents=new JSONArray();JSONObject content=new JSONObject();JSONArray parts=new JSONArray();parts.put(new JSONObject().put("text","Reply only OK"));content.put("parts",parts);contents.put(content);body.put("contents",contents);
            HttpResult r=httpPost(GEMINI_BASE+"/"+model+":generateContent",body.toString(),key,30000);
            if(r.code==200)return new GeminiCheck("VALID",model.replace("models/",""));
            if(r.code==429){return isQuota(r.body)?new GeminiCheck("QUOTA_EXCEEDED",model.replace("models/","")):new GeminiCheck("RATE_LIMITED",model.replace("models/",""));}
            if(r.code==401||r.code==403)return new GeminiCheck("INVALID",model.replace("models/",""));
            return new GeminiCheck("ERROR_"+r.code,model.replace("models/",""));
        }catch(Exception e){return new GeminiCheck("NETWORK_ERROR","");}
    }

    private String chooseModel(String body){
        try{JSONArray ms=new JSONObject(body).optJSONArray("models");String fallback="";String[] pref={"models/gemini-2.5-flash","models/gemini-2.0-flash","models/gemini-2.5-flash-lite","models/gemini-2.0-flash-lite"};for(String p:pref)for(int i=0;i<(ms==null?0:ms.length());i++){JSONObject m=ms.getJSONObject(i);if(p.equals(m.optString("name"))&&supportsGenerate(m))return p;}for(int i=0;i<(ms==null?0:ms.length());i++){JSONObject m=ms.getJSONObject(i);String n=m.optString("name");if(supportsGenerate(m)&&n.toLowerCase(Locale.US).contains("flash")&&!n.toLowerCase(Locale.US).contains("image"))return n;if(fallback.isEmpty()&&supportsGenerate(m))fallback=n;}return fallback;}catch(Exception e){return "";}}
    private boolean supportsGenerate(JSONObject m)throws Exception{JSONArray a=m.optJSONArray("supportedGenerationMethods");for(int i=0;i<(a==null?0:a.length());i++)if("generateContent".equals(a.getString(i)))return true;return false;}
    private boolean isQuota(String body){String s=body==null?"":body.toLowerCase(Locale.US);return s.contains("quota")||s.contains("resource_exhausted")||s.contains("daily");}

    private void testBackend(){pool.submit(()->{try{HttpResult r=httpGet(base()+"/api/health",null,15000);runOnUiThread(()->toast(r.code==200?"Backend terhubung":"Backend HTTP "+r.code));}catch(Exception e){runOnUiThread(()->toast("Gagal konek: "+e.getMessage()));}});}

    private void analyze(String url,int duration,int count){
        // v4.1: key yang sedang diketik juga otomatis didaftarkan.
        if(!keyInput.getText().toString().trim().isEmpty()) addCurrentInputIfNeeded();
        JSONArray keys=loadKeys();
        if(keys.length()==0){toast("Tambahkan minimal 1 Gemini API Key");return;}
        progress.setVisibility(View.VISIBLE);status.setText("Backend: download audio + Whisper transkripsi. Untuk video 1 jam+ proses bisa cukup lama...");result.setText("");resultButtons.removeAllViews();
        pool.submit(()->{try{
            JSONObject req=new JSONObject().put("youtube_url",url);
            String raw=post(base()+"/api/transcribe",req.toString(),900000);
            JSONObject tr=new JSONObject(raw);lastJobId=tr.optString("job_id");JSONArray chunks=tr.optJSONArray("chunks");if(chunks==null||chunks.length()==0)throw new Exception("Transkrip kosong");
            runOnUiThread(()->status.setText("Transkripsi selesai. Gemini menganalisis "+chunks.length()+" bagian..."));
            JSONArray clips=analyzeWithGemini(keys,chunks,duration,count);
            JSONObject out=new JSONObject();out.put("job_id",lastJobId);out.put("clips",clips);
            runOnUiThread(()->{progress.setVisibility(View.GONE);status.setText("Selesai. Gemini dipanggil langsung dari APK.");showResult(out.toString());});
        }catch(Exception e){runOnUiThread(()->{progress.setVisibility(View.GONE);status.setText("Gagal: "+e.getMessage());});}});
    }

    private JSONArray analyzeWithGemini(JSONArray keys,JSONArray chunks,int duration,int count)throws Exception{
        JSONArray all=new JSONArray();int keyIndex=0;
        for(int i=0;i<chunks.length();i++){
            JSONObject ch=chunks.getJSONObject(i);String text=ch.optString("text","");if(text.isEmpty())continue;
            boolean ok=false;int attempts=0;
            while(attempts<keys.length()&&!ok){String key=keys.getJSONObject(keyIndex%keys.length()).optString("key");keyIndex++;attempts++;try{
                String model=getModelForKey(key);if(model.isEmpty())throw new Exception("Tidak ada model Gemini Flash untuk key");
                String prompt="You are a professional short-form YouTube editor. Analyze this timestamped transcript section and find the strongest moments for short clips. Requested clip length about "+duration+" seconds. Return ONLY valid JSON: {\"clips\":[{\"title\":\"...\",\"start\":\"HH:MM:SS\",\"end\":\"HH:MM:SS\",\"score\":0,\"reason\":\"...\"}]}. Pick hooks, surprises, useful insights, humor, emotion, conflict or payoff. Keep timestamps inside the supplied section. Aim for 2 candidates. Do not invent timestamps. Score 0-100. Transcript section:\n"+text;
                JSONObject body=new JSONObject();JSONArray contents=new JSONArray();JSONObject c=new JSONObject();c.put("parts",new JSONArray().put(new JSONObject().put("text",prompt)));contents.put(c);body.put("contents",contents);JSONObject gen=new JSONObject();gen.put("temperature",0.2);gen.put("responseMimeType","application/json");gen.put("maxOutputTokens",1200);body.put("generationConfig",gen);
                HttpResult r=httpPost(GEMINI_BASE+"/"+model+":generateContent",body.toString(),key,180000);
                if(r.code==429){markKey(key,"RATE_LIMITED",model);continue;}if(r.code==401||r.code==403){markKey(key,"INVALID",model);continue;}if(r.code>=400)continue;
                String txt=extractText(r.body);JSONObject jo=new JSONObject(txt);JSONArray got=jo.optJSONArray("clips");if(got!=null)for(int j=0;j<got.length();j++)all.put(got.getJSONObject(j));ok=true;markKey(key,"VALID",model);
            }catch(Exception ignored){}}
            final int done=i+1;runOnUiThread(()->status.setText("Gemini: bagian "+done+"/"+chunks.length()));
        }
        return normalizeCandidates(all,duration,count);
    }

    private String getModelForKey(String key)throws Exception{JSONArray a=loadKeys();for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(key.equals(o.optString("key"))&&!o.optString("model").isEmpty())return "models/"+o.optString("model");}HttpResult r=httpGet(GEMINI_BASE+"/models",key,30000);if(r.code!=200)throw new Exception("Key tidak bisa mengakses models: HTTP "+r.code);String m=chooseModel(r.body);if(!m.isEmpty())markKey(key,"VALID",m);return m;}
    private void markKey(String key,String status,String model){
        JSONArray a=loadKeys();
        for(int i=0;i<a.length();i++) try{
            JSONObject o=a.getJSONObject(i);
            if(key.equals(o.optString("key"))){
                o.put("status",status);
                o.put("model",model.replace("models/",""));
                break;
            }
        }catch(Exception ignored){}
        saveKeys(a);
    }
    private String extractText(String body)throws Exception{JSONObject root=new JSONObject(body);JSONArray c=root.optJSONArray("candidates");if(c==null||c.length()==0)throw new Exception("Gemini tidak memberi kandidat");JSONArray p=c.getJSONObject(0).getJSONObject("content").optJSONArray("parts");StringBuilder s=new StringBuilder();for(int i=0;i<(p==null?0:p.length());i++)s.append(p.getJSONObject(i).optString("text",""));String x=s.toString().trim();int a=x.indexOf('{'),b=x.lastIndexOf('}');if(a>=0&&b>a)x=x.substring(a,b+1);return x;}

    private JSONArray normalizeCandidates(JSONArray input,int duration,int count){try{ArrayList<JSONObject> list=new ArrayList<>();for(int i=0;i<input.length();i++){JSONObject c=input.getJSONObject(i);int st=time(c.optString("start")),en=time(c.optString("end"));if(en<=st)continue;if(en-st>duration*1.35){int center=(st+en)/2;st=Math.max(0,center-duration/2);en=st+duration;}else if(en-st<Math.max(12,duration*0.45))en=st+duration;c.put("start",fmt(st));c.put("end",fmt(en));c.put("score",Math.max(0,Math.min(100,c.optInt("score",0))));list.add(c);}list.sort((a,b)->Integer.compare(b.optInt("score",0),a.optInt("score",0)));JSONArray out=new JSONArray();for(JSONObject c:list){if(out.length()>=count)break;boolean overlap=false;int a=time(c.optString("start")),b=time(c.optString("end"));for(int j=0;j<out.length();j++){JSONObject x=out.getJSONObject(j);int x1=time(x.optString("start")),x2=time(x.optString("end"));int inter=Math.max(0,Math.min(b,x2)-Math.max(a,x1));if(inter>0.35*Math.min(b-a,x2-x1)){overlap=true;break;}}if(!overlap)out.put(c);}return out;}catch(Exception e){return input;}}
    private int time(String s){String[] p=s.trim().split(":");if(p.length==2)return Integer.parseInt(p[0])*60+Integer.parseInt(p[1]);if(p.length==3)return Integer.parseInt(p[0])*3600+Integer.parseInt(p[1])*60+Integer.parseInt(p[2]);throw new IllegalArgumentException();}
    private String fmt(int sec){sec=Math.max(0,sec);int h=sec/3600;sec%=3600;int m=sec/60,s=sec%60;return String.format(Locale.US,"%02d:%02d:%02d",h,m,s);}

    private void showResult(String raw){try{JSONObject o=new JSONObject(raw);lastJobId=o.optString("job_id",lastJobId);JSONArray clips=o.optJSONArray("clips");if(clips==null){result.setText(raw);return;}result.setText("Ditemukan "+clips.length()+" kandidat terbaik.\n\n");for(int i=0;i<clips.length();i++){JSONObject c=clips.getJSONObject(i);result.append("#"+(i+1)+" "+c.optString("title","Clip")+"\n");result.append(c.optString("start")+" → "+c.optString("end")+" • "+c.optInt("score",0)+"/100\n");result.append(c.optString("reason","")+"\n\n");Button b=btn("✂ BUAT CLIP MP4");final JSONObject clip=c;b.setOnClickListener(v->makeClip(clip));resultButtons.addView(b);}}catch(Exception e){result.setText(raw);}}

    private void makeClip(JSONObject clip){pool.submit(()->{try{JSONObject req=new JSONObject();req.put("job_id",lastJobId);req.put("youtube_url",youtube.getText().toString().trim());req.put("start",clip.optString("start"));req.put("end",clip.optString("end"));String r=post(base()+"/api/clip",req.toString(),900000);JSONObject o=new JSONObject(r);String dl=o.optString("download","");runOnUiThread(()->{Button b=btn("⬇ BUKA / DOWNLOAD CLIP");b.setOnClickListener(v->startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(base()+dl))));resultButtons.addView(b);toast("Clip selesai");});}catch(Exception e){runOnUiThread(()->toast("Clip gagal: "+e.getMessage()));}});}

    private static class HttpResult{int code;String body;HttpResult(int c,String b){code=c;body=b;}}
    private HttpResult httpGet(String u,String key,int timeout)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setRequestMethod("GET");c.setConnectTimeout(timeout);c.setReadTimeout(timeout);if(key!=null)c.setRequestProperty("x-goog-api-key",key);int code=c.getResponseCode();InputStream is=code>=400?c.getErrorStream():c.getInputStream();String body=is==null?"":readStream(is);c.disconnect();return new HttpResult(code,body);}
    private HttpResult httpPost(String u,String body,String key,int timeout)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setRequestMethod("POST");c.setConnectTimeout(timeout);c.setReadTimeout(timeout);c.setRequestProperty("Content-Type","application/json");if(key!=null)c.setRequestProperty("x-goog-api-key",key);c.setDoOutput(true);try(OutputStream os=c.getOutputStream()){os.write(body.getBytes(StandardCharsets.UTF_8));}int code=c.getResponseCode();InputStream is=code>=400?c.getErrorStream():c.getInputStream();String out=is==null?"":readStream(is);c.disconnect();return new HttpResult(code,out);}
    private String post(String u,String body,int timeout)throws Exception{HttpResult r=httpPost(u,body,null,timeout);if(r.code>=400)throw new IOException("HTTP "+r.code+": "+r.body);return r.body;}

    private String readStream(InputStream is)throws Exception{if(is==null)return "";ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=is.read(buf))!=-1)b.write(buf,0,n);return new String(b.toByteArray(),StandardCharsets.UTF_8);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
