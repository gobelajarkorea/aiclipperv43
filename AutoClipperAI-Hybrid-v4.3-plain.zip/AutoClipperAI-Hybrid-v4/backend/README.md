# AutoClipper AI v3 Backend

Backend ini mengubah URL YouTube menjadi transkripsi bertimestamp, meminta Gemini memilih momen terbaik, lalu membuat MP4 dengan FFmpeg.

## Install di Linux/VPS

```bash
sudo apt update
sudo apt install -y ffmpeg python3 python3-pip
cd backend
python3 -m pip install -r requirements.txt
python3 -m uvicorn main:app --host 0.0.0.0 --port 8000
```

## Install di Termux

```bash
pkg update
pkg install python ffmpeg
cd backend
pip install -r requirements.txt
python -m uvicorn main:app --host 0.0.0.0 --port 8000
```

Untuk HP fisik, jangan gunakan `10.0.2.2` kecuali backend berada di host emulator. Gunakan IP LAN perangkat yang menjalankan backend, misalnya `http://192.168.1.5:8000`.

## Untuk video 1 jam+

Faster-Whisper mentranskripsi seluruh audio dengan timestamp. Transcript kemudian dibagi menjadi beberapa bagian dan dianalisis Gemini secara bergiliran. Atur model dengan:

```bash
export WHISPER_MODEL=small
export MAX_GEMINI_CHUNKS=8
```

Model `medium` lebih akurat tetapi jauh lebih berat. Video 1 jam dapat membutuhkan beberapa menit atau lebih tergantung CPU/RAM.

## Gemini key rotation

Aplikasi mengirim beberapa key. Backend mengambil daftar model yang bisa `generateContent` untuk setiap key, lalu memprioritaskan model Flash yang tersedia. Jika satu key rate-limited/error, backend pindah ke key berikutnya.

Pengecekan key di aplikasi adalah pengecekan akses + request kecil. Gemini tidak menyediakan angka sisa quota umum dari endpoint ini, sehingga aplikasi tidak mengarang angka quota.
