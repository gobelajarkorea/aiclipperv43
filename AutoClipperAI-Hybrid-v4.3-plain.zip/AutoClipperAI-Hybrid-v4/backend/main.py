import json
import os
import re
import shutil
import subprocess
import uuid
from pathlib import Path
from typing import List

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

try:
    from faster_whisper import WhisperModel
except Exception:
    WhisperModel = None

app = FastAPI(title="AutoClipper AI Hybrid Backend v4")
BASE = Path(__file__).resolve().parent
WORK = BASE / "work"
WORK.mkdir(exist_ok=True)
WHISPER_MODEL = os.getenv("WHISPER_MODEL", "small")
MAX_TRANSCRIPT_CHUNKS = int(os.getenv("MAX_TRANSCRIPT_CHUNKS", "16"))
_whisper = None

class TranscribeReq(BaseModel):
    youtube_url: str

class ClipReq(BaseModel):
    job_id: str
    youtube_url: str = ""
    start: str
    end: str

@app.get("/api/health")
def health():
    return {
        "ok": True,
        "service": "AutoClipper AI Hybrid v4",
        "role": "media-worker",
        "whisper_model": WHISPER_MODEL,
        "ffmpeg": shutil.which("ffmpeg") is not None,
        "yt_dlp": shutil.which("yt-dlp") is not None,
    }

def run(cmd, timeout):
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    if p.returncode != 0:
        raise RuntimeError(p.stderr[-5000:] or "Command gagal")
    return p

def job_dir(job_id=None):
    jid = job_id or uuid.uuid4().hex
    p = WORK / jid
    p.mkdir(parents=True, exist_ok=True)
    return jid, p

def download_audio(url: str, job: Path) -> Path:
    out = str(job / "audio.%(ext)s")
    run(["yt-dlp", "--no-playlist", "-x", "--audio-format", "mp3", "-o", out, url], 7200)
    mp3 = job / "audio.mp3"
    if mp3.exists():
        return mp3
    found = list(job.glob("audio.*"))
    if not found:
        raise RuntimeError("Audio tidak ditemukan setelah yt-dlp")
    return found[0]

def get_whisper():
    global _whisper
    if WhisperModel is None:
        raise RuntimeError("faster-whisper belum terpasang. Jalankan pip install -r requirements.txt")
    if _whisper is None:
        device = os.getenv("WHISPER_DEVICE", "cpu")
        compute = os.getenv("WHISPER_COMPUTE", "int8")
        _whisper = WhisperModel(WHISPER_MODEL, device=device, compute_type=compute)
    return _whisper

def transcribe(audio: Path, job: Path):
    model = get_whisper()
    segments, info = model.transcribe(str(audio), beam_size=5, vad_filter=True, condition_on_previous_text=True)
    rows = []
    for s in segments:
        text = (s.text or "").strip()
        if text:
            rows.append({"start": float(s.start), "end": float(s.end), "text": text})
    if not rows:
        raise RuntimeError("Transkripsi kosong")
    (job / "transcript.json").write_text(json.dumps({"language": info.language, "segments": rows}, ensure_ascii=False), encoding="utf-8")
    return rows, info.language

def fmt_time(sec: float) -> str:
    sec = max(0, int(round(sec)))
    h, sec = divmod(sec, 3600)
    m, s = divmod(sec, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"

def build_chunks(rows, max_chunks=MAX_TRANSCRIPT_CHUNKS):
    total_end = rows[-1]["end"] if rows else 0
    if not rows or total_end <= 0:
        return []
    # For long videos, use up to 16 sections so Gemini receives manageable text windows.
    count = max(1, min(max_chunks, int(total_end / 300) + 1))
    chunk_len = total_end / count
    chunks = []
    for i in range(count):
        start = i * chunk_len
        end = total_end if i == count - 1 else (i + 1) * chunk_len
        parts = [f"[{fmt_time(x['start'])} - {fmt_time(x['end'])}] {x['text']}" for x in rows if x["end"] >= start and x["start"] < end]
        if parts:
            chunks.append({"start": start, "end": end, "text": "\n".join(parts)})
    return chunks

@app.post("/api/transcribe")
def transcribe_endpoint(req: TranscribeReq):
    if not req.youtube_url.strip():
        raise HTTPException(400, "youtube_url kosong")
    try:
        jid, job = job_dir()
        audio = download_audio(req.youtube_url.strip(), job)
        rows, language = transcribe(audio, job)
        chunks = build_chunks(rows)
        (job / "meta.json").write_text(json.dumps({"youtube_url": req.youtube_url.strip(), "language": language}, ensure_ascii=False), encoding="utf-8")
        return {
            "ok": True,
            "job_id": jid,
            "language": language,
            "duration": rows[-1]["end"],
            "chunks": chunks,
        }
    except Exception as e:
        raise HTTPException(500, str(e))

def valid_time(s: str) -> int:
    parts = s.strip().split(":")
    if len(parts) == 2:
        return int(parts[0]) * 60 + int(parts[1])
    if len(parts) == 3:
        return int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
    raise ValueError("format waktu tidak valid")

def ensure_video(job: Path, youtube_url: str):
    video = job / "source.mp4"
    if video.exists() and video.stat().st_size > 1_000_000:
        return video
    url = youtube_url.strip()
    if not url:
        meta = job / "meta.json"
        if meta.exists():
            url = json.loads(meta.read_text(encoding="utf-8")).get("youtube_url", "")
    if not url:
        raise RuntimeError("URL YouTube tidak tersedia")
    run(["yt-dlp", "--no-playlist", "-f", "bv*+ba/b", "--merge-output-format", "mp4", "-o", str(video), url], 7200)
    if not video.exists():
        raise RuntimeError("Video tidak ditemukan setelah yt-dlp")
    return video

@app.post("/api/clip")
def clip(req: ClipReq):
    try:
        job = WORK / req.job_id
        if not job.exists():
            raise RuntimeError("Job tidak ditemukan. Jalankan analisis/transkripsi lagi.")
        st, en = valid_time(req.start), valid_time(req.end)
        if en <= st or en - st > 600:
            raise RuntimeError("Rentang clip tidak valid")
        video = ensure_video(job, req.youtube_url)
        clips = job / "clips"
        clips.mkdir(exist_ok=True)
        filename = f"clip_{st}_{en}.mp4"
        out = clips / filename
        run(["ffmpeg", "-y", "-ss", str(st), "-i", str(video), "-t", str(en-st), "-c:v", "libx264", "-preset", "veryfast", "-c:a", "aac", "-movflags", "+faststart", str(out)], 7200)
        if not out.exists():
            raise RuntimeError("FFmpeg tidak menghasilkan clip")
        return {"ok": True, "download": f"/api/download/{req.job_id}/{filename}", "filename": filename}
    except Exception as e:
        raise HTTPException(500, str(e))

@app.get("/api/download/{job_id}/{filename}")
def download(job_id: str, filename: str):
    p = WORK / job_id / "clips" / filename
    if not p.exists() or p.name != filename:
        raise HTTPException(404, "File tidak ditemukan")
    return FileResponse(str(p), media_type="video/mp4", filename=p.name)
