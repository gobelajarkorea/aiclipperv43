# AutoClipper AI Hybrid v4.2

Arsitektur:
- Android APK: UI, penyimpanan API key terenkripsi, pengecekan key, pemanggilan Gemini, rotasi key saat 429/quota.
- Backend media-worker: yt-dlp + faster-whisper + FFmpeg. Backend tidak menerima Gemini API key.

## Backend

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

Pastikan `yt-dlp` dan `ffmpeg` tersedia di PATH.

## APK

Masukkan URL backend, misalnya:
- Termux/HP yang sama melalui alamat yang dapat dijangkau jaringan.
- PC/VPS di jaringan lokal.

Masukkan Gemini API key di aplikasi. Key disimpan terenkripsi lokal dan tidak dikirim ke backend.

Untuk video 1 jam+, backend membuat transkrip lalu membaginya menjadi beberapa bagian. APK mengirim bagian tersebut ke Gemini satu per satu dan mengganti key ketika API mengembalikan rate-limit/quota error.

Catatan: API Gemini tidak memberikan angka "sisa kuota" umum dari endpoint generateContent. Aplikasi menampilkan status berdasarkan respons API.
